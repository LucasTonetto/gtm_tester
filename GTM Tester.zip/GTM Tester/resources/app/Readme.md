# GTM Tester

## Objetivo
A aplicação GTM Tester foi criada com o objetivo de disponibilizar um ambiente próprio com templates de websites para inserção de tags do GTM.

## Copyright e Créditos
- O site [Dopetrope](https://html5up.net/dopetrope) foi disponibilizado pela [HTML5 UP](https://html5up.net/).
- O site de [e-commerce](https://github.com/chekromul/uikit-ecommerce-template) foi disponibilizado via Github pelo usuário [chekromul](https://github.com/chekromul) - MIT License.